import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        //DECLARACION DE VARIABLES Y ENTRADAS
        Scanner scanner = new Scanner(System.in);
        
        int ACUMULADOR;
        int CONTADOR;
        int BANDERA;
        String Option;

        //INICIO DE PROCESOS - SOLICITUD DE DATOS
        ACUMULADOR = 0;
        CONTADOR = 1;
        System.out.println("INDICA EL RANGO DE LA SUMA");
        BANDERA = scanner.nextInt();
        System.out.println("\nQUE OPCION QUIERES USAR PARA SUMAR DE LAS POSIBLES");
        System.out.println("A = WHILE B = DO WHILE C = FOR\n");
        Option = scanner.nextLine();

        //ESTRUCTURA DE TRABAJO SELECTIVA - S
        switch (Option) {
            // CASO A - WHILE
            case "A":
                while (CONTADOR <= BANDERA) {
                    ACUMULADOR = ACUMULADOR + CONTADOR;
                    CONTADOR = CONTADOR++;
                }
                System.out.println("LA SUMA TOTAL ES DE: " + ACUMULADOR);
            break;
            // CASO B - DO WHILE
            case "B":
                do {
                    ACUMULADOR = ACUMULADOR + CONTADOR;
                    CONTADOR = CONTADOR++;
                } while (CONTADOR <= BANDERA);
                System.out.println("LA SUMA TOTAL ES DE: " + ACUMULADOR);
            break;
            // CASO C - FOR
            case "C":
                for (CONTADOR = 0; CONTADOR < BANDERA; CONTADOR++) {
                    ACUMULADOR = ACUMULADOR + CONTADOR;
                    CONTADOR = CONTADOR++;
                }
                System.out.println("LA SUMA TOTAL ES DE: " + ACUMULADOR);
            break;

            default:
            System.out.println("NO EXISTE LO INDICADO, POR FAVOR INTENTA DE NUEVO");
            break;
        }
    }
}
